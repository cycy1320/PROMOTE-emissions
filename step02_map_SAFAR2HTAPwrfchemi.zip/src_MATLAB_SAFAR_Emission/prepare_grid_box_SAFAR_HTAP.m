
%% calc SAFAR grid BOX
lat_safar=ncread(safar_file,'lat');
long_safar=ncread(safar_file,'lon');
var=ncread(safar_file,'ind');
[lat_safar, long_safar] = meshgrid(lat_safar, long_safar);
% lat_safar=lat_safar'; long_safar=long_safar';
% pcolor(long_safar, lat_safar, log10(var'));

X_SAFAR=[]; Y_SAFAR=[]; WIDTH_SAFAR=[]; HEIGHT_SAFAR=[];
for i=1:size(lat_safar,1)
    for j=1:size(lat_safar,2)
        if j~=size(lat_safar,2)
            dy=lat_safar(i,j+1)-lat_safar(i,j);
        else
            dy=lat_safar(i,j)-lat_safar(i,j-1);
        end
        
        if i~=size(lat_safar,1)
            dx=long_safar(i+1,j)-long_safar(i,j);
        else
            dx=long_safar(i,j)-long_safar(i-1,j);
        end
        
        X_SAFAR(i,j)=long_safar(i,j)-dx/2;
        Y_SAFAR(i,j)=lat_safar(i,j)-dy/2;
        WIDTH_SAFAR(i,j)=dx;
        HEIGHT_SAFAR(i,j)=dy; 
end
end
BOX_SAFAR=[X_SAFAR(:), Y_SAFAR(:), WIDTH_SAFAR(:), HEIGHT_SAFAR(:)];
AREA_SAFAR=WIDTH_SAFAR.*HEIGHT_SAFAR;








    wrfchemi00=[HTAP_path, 'wrfchemi_00z', DOMAIN{d}];
    wrfchemi12=[HTAP_path, 'wrfchemi_12z', DOMAIN{d}];
    

    
    lat_wrf=ncread(wrfchemi00,'XLAT'); % lat_wrf= lat_wrf';
    long_wrf=ncread(wrfchemi00,'XLONG'); % long_wrf= long_wrf';
    
    %% calc rectangle grid box
    X_WRF=[]; Y_WRF=[]; WIDTH_WRF=[]; HEIGHT_WRF=[];
    for i=1:size(lat_wrf,1)
    for j=1:size(lat_wrf,2)
        if j~=size(lat_wrf,2)
            dy=lat_wrf(i,j+1)-lat_wrf(i,j);
        else
            dy=lat_wrf(i,j)-lat_wrf(i,j-1);
        end
        
        if i~=size(lat_wrf,1)
            dx=long_wrf(i+1,j)-long_wrf(i,j);
        else
            dx=long_wrf(i,j)-long_wrf(i-1,j);
        end
        
        X_WRF(i,j)=long_wrf(i,j)-dx/2;
        Y_WRF(i,j)=lat_wrf(i,j)-dy/2;
        WIDTH_WRF(i,j)=dx;
        HEIGHT_WRF(i,j)=dy; 
    end
    end
BOX_WRF=[X_WRF(:), Y_WRF(:), WIDTH_WRF(:), HEIGHT_WRF(:)];    
AREA_WRF=WIDTH_WRF.*HEIGHT_WRF;
    



AREA=[];    RATIO=[];
for i=1:size(X_WRF,1)
for j=1:size(X_WRF,2)
    area=rectint([X_WRF(i,j),Y_WRF(i,j),WIDTH_WRF(i,j),HEIGHT_WRF(i,j)],[BOX_SAFAR]);
    ratio=sum(area(:))/AREA_WRF(i,j);
    RATIO(i,j)=[ratio];
end
end
RATIO_SAFAR=RATIO;
[I_RATIO_SAFAR, J_RATIO_SAFAR]=find(RATIO_SAFAR~=0);    