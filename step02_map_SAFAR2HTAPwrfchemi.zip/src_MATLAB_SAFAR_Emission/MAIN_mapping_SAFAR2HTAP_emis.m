clear all
close all
fclose all
clc


VAR_NAME= {'E_SO2'; 'E_NO'; 'E_NO2'; 'E_CO';  'E_PM_10'; 'E_PM25I'; 'E_PM25J'; 'E_ECI'; 'E_ECJ'; 'E_ORGI'; 'E_ORGJ'; 'E_SO4I'; 'E_SO4J'; 'E_NO3I'; 'E_NO3J'; };
VAR_SAFAR={'SO2';   'NOX';  'NOX';   'CO';      'PM10';     'PM2_5';    'PM2_5';   'BC';     'BC';    'OC';     'OC';  'PM2_5';  'PM2_5';  'PM2_5';  'PM2_5';         };
DOMAIN={'_d01'; '_d02'; '_d03'; '_d04'; };
MONTH=01;

%%                 1  2  3   4   5   6   7   8   9   10  11  12
MONTH_FACTOR=     [1  1  1   1   1   1   1   1   1   1   1   1];
DIURNAL_FACTOR=   [1  1  1   1   1   1   1   1   1   1   1   1    1  1  1   1   1   1   1   1   1   1   1   1];

      


SAFAR_path='../SAFAR_netcdf/original/';
HTAP_path='../HTAP_wrfchemi/';
SAFAR_HTAP_path='../SAFAR_netcdf/HTAPandSAFAR_MONTHfactor/';



safar_file=[SAFAR_path, 'SAFAR_', 'CO', '_2015.nc'];


for d=1:numel(DOMAIN)
    prepare_grid_box_SAFAR_HTAP;  % output BOXes of SAFAR and HTAP, I_RATIO_SAFAR, J_RATIO_SAFAR

    wrfchemi00_out=[SAFAR_HTAP_path, 'wrfchemi_00z', DOMAIN{d}];
    wrfchemi12_out=[SAFAR_HTAP_path, 'wrfchemi_12z', DOMAIN{d}];
    
        
        

for v=1:numel(VAR_NAME)
    safar_file=[SAFAR_path, 'SAFAR_', VAR_SAFAR{v}, '_2015.nc'];
    
    %% unit: kg/m2/s --> mol/km2/hour for gas,  --> ug/m2/s for particle
    safar_unit_factor=HTAP2wrfchemi_unit(VAR_NAME{v});
    
    
    safar_ind=ncread(safar_file,'ind'); % safar_ind=safar_ind';
    safar_pow=ncread(safar_file,'pow'); % safar_pow=safar_pow';
    safar_tra=ncread(safar_file,'tra'); % safar_tra=safar_tra';
    safar_res=ncread(safar_file,'res'); % safar_res=safar_res';
    safar_tot= safar_ind+safar_pow+safar_res+safar_tra; safar_tot=safar_tot * safar_unit_factor;
%     safar_tot= safar_tra * safar_unit_factor;
    
    
    
    
    
    %% 00z
    var_wrf=ncread(wrfchemi00,VAR_NAME{v}); % var_wrf_00z=var_wrf_00z';
    for i=1:numel(I_RATIO_SAFAR)
        box_wrf=[X_WRF(I_RATIO_SAFAR(i), J_RATIO_SAFAR(i)),Y_WRF(I_RATIO_SAFAR(i), J_RATIO_SAFAR(i)),WIDTH_WRF(I_RATIO_SAFAR(i), J_RATIO_SAFAR(i)),HEIGHT_WRF(I_RATIO_SAFAR(i), J_RATIO_SAFAR(i))];
        area=rectint(box_wrf,[BOX_SAFAR]);  % calc overlap area [deg.^2]
        ratio_safar=area(:)./AREA_SAFAR(:);
        temp_safar=safar_tot(:).*ratio_safar(:); temp_safar=sum(temp_safar(:))/sum(ratio_safar(:)) *RATIO_SAFAR(I_RATIO_SAFAR(i), J_RATIO_SAFAR(i));
        temp_safar = temp_safar .* MONTH_FACTOR(MONTH) .* DIURNAL_FACTOR(1:12);   %% .* vertifcal_factor; 
        temp_wrf=(1-RATIO_SAFAR(I_RATIO_SAFAR(i), J_RATIO_SAFAR(i))).*var_wrf(I_RATIO_SAFAR(i), J_RATIO_SAFAR(i),:,:); %% ying
        temp_safar=reshape(temp_safar,size(temp_wrf));
        temp=temp_safar+temp_wrf;
        var_wrf(I_RATIO_SAFAR(i), J_RATIO_SAFAR(i), :,:)=temp;  
        
        ncwrite(wrfchemi00_out, VAR_NAME{v}, var_wrf);
    end
    
    
    
    
    %% 12z
    var_wrf=ncread(wrfchemi12,VAR_NAME{v}); % var_wrf_00z=var_wrf_00z';
    for i=1:numel(I_RATIO_SAFAR)
        box_wrf=[X_WRF(I_RATIO_SAFAR(i), J_RATIO_SAFAR(i)),Y_WRF(I_RATIO_SAFAR(i), J_RATIO_SAFAR(i)),WIDTH_WRF(I_RATIO_SAFAR(i), J_RATIO_SAFAR(i)),HEIGHT_WRF(I_RATIO_SAFAR(i), J_RATIO_SAFAR(i))];
        area=rectint(box_wrf,[BOX_SAFAR]);  % calc overlap area
        ratio_safar=area(:)./AREA_SAFAR(:);
        temp_safar=safar_tot(:).*ratio_safar(:); temp_safar=sum(temp_safar(:))/sum(ratio_safar(:)) *RATIO_SAFAR(I_RATIO_SAFAR(i), J_RATIO_SAFAR(i));
        temp_safar = temp_safar .* MONTH_FACTOR(MONTH) .* DIURNAL_FACTOR(13:24);   %% .* vertifcal_factor; 
        temp_wrf=(1-RATIO_SAFAR(I_RATIO_SAFAR(i), J_RATIO_SAFAR(i))).*var_wrf(I_RATIO_SAFAR(i), J_RATIO_SAFAR(i),:,:); %% ying
        temp_safar=reshape(temp_safar,size(temp_wrf));
        temp=temp_safar+temp_wrf;
        var_wrf(I_RATIO_SAFAR(i), J_RATIO_SAFAR(i), :,:)=temp;  
        
        ncwrite(wrfchemi12_out, VAR_NAME{v}, var_wrf);
    end

    
    
    
    
    
end
end
