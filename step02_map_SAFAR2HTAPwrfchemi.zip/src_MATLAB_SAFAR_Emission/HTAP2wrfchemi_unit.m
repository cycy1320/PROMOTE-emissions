function factor=HTAP2wrfchemi_unit(VAR_NAME)



 m_CO=28;    m_NOx=31.6; m_BIGALK=72;   m_BIGENE=56;  m_C2H4=28;  m_C2H5OH=46;
 m_C2H6=30;  m_C3H6=42;  m_C3H8=44;     m_CH2O=30;  m_CH3CHO=44;
 m_CH3OH=32; m_SO2=64;   m_TOLUENE=92;  m_NH3=17;   m_CH3COCH3MEK=65;  m_XYLENE=106;
 m_OC=12;    m_BC=12;    m_PM25=1;     m_PM10=1;   m_PM25other=1;     m_PMcoarse=1;
 
 
 %% gaseous 
 if strfind(VAR_NAME,'CO')==3
     m_mole=m_CO;
     factor = 1*1000/m_mole*3600*1000^2; 
              %    mol/km2/hour     
 elseif strfind(VAR_NAME,'NO2')==3
     m_mole=m_NOx;
     factor = 1*1000/m_mole*3600*1000^2; 
     factor = factor *0.1;  % 10% NOx = NO2
     
 elseif strfind(VAR_NAME,'NO')==3
     m_mole=m_NOx;
     factor = 1*1000/m_mole*3600*1000^2; 
     factor = factor *0.9;  % 90% NOx = NO2
 elseif strfind(VAR_NAME,'SO2')==3
     m_mole=m_SO2;
     factor = 1*1000/m_mole*3600*1000^2; 
 elseif strfind(VAR_NAME,'NH3')==3
     m_mole=m_NH3;
     factor = 1*1000/m_mole*3600*1000^2; 
     
     
     
 %% Particles    
 elseif strfind(VAR_NAME,'ORGI')==3
     m_mole=m_OC;
     factor = 1*1000*1e6;
     factor = factor *0.28;  % OA(ORGJ)=1.4*OC;
 elseif strfind(VAR_NAME,'ORGJ')==3
     m_mole=m_OC;
     factor = 1*1000*1e6; 
     factor = factor *1.12;  % OA(ORGJ)=1.4*OC;
 elseif strfind(VAR_NAME,'ECI')==3
     m_mole=m_BC;
     factor = 1*1000*1e6; 
     factor = factor *0.2;
 elseif strfind(VAR_NAME,'ECJ')==3
     m_mole=m_BC;
     factor = 1*1000*1e6;
     factor = factor *0.8;
 elseif strfind(VAR_NAME,'SO4I')==3
     m_mole=m_PM25other;
     factor = 1*1000*1e6;
     factor = factor *0.0148;  % * PMother
 elseif strfind(VAR_NAME,'SO4J')==3
     m_mole=m_PM25other;
     factor = 1*1000*1e6;
     factor = factor *0.0592;  % * PMother
elseif strfind(VAR_NAME,'NO3I')==3
     m_mole=m_PM25other;
     factor = 1*1000*1e6;   
     factor = factor *0.0076;  % * PM25other
elseif strfind(VAR_NAME,'NO3J')==3
     m_mole=m_PM25other;
     factor = 1*1000*1e6;
     factor = factor *0.0304;
elseif strfind(VAR_NAME,'PM25I')==3
     m_mole=m_PM25other;
     factor = 1*1000*1e6;
     factor = factor *0.18;  % PM25other
elseif strfind(VAR_NAME,'PM25J')==3
     m_mole=m_PM25other;
     factor = 1*1000*1e6;
     factor = factor *0.72;
elseif strfind(VAR_NAME,'PM_10')==3
     m_mole=m_PM25other;
     factor = 1*1000*1e6;
     
     
     
 %% NMVOCs    
%   elseif 
     
     
     
     
 end
