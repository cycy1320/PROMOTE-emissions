#!/bin/bash




WORKPATH=`pwd | awk '{print $1}'`
echo $WORKPATH

export PATH_NCL_SRC=./src_ncl/emission_csv_to_netcdf_conversion_fromDoug
export PATH_MAT_SRC=./src_MATLAB_SAFAR_Emission


#ls -lh $PATH_NCL_SRC/*

mkdir SAFAR_netcdf
mkdir SAFAR_netcdf/original
mkdir SAFAR_netcdf/HTAPandSAFAR_MONTHfactor
mkdir SAFAR_netcdf/DUIRNAL_CYCLE
mkdir SAFAR_netcdf/DUIRNAL_VERTICAL


cd $PATH_NCL_SRC
ncl MAIN_SAFAR_convert_csv_to_netcdf.ncl
mv SAFAR_* $WORKPATH/SAFAR_netcdf/original/

cd $WORKPATH
cp ./HTAP_wrfchemi/wrfchemi_* ./SAFAR_netcdf/HTAPandSAFAR_MONTHfactor/
cd $PATH_MAT_SRC
matlab -nodisplay < MAIN_mapping_SAFAR2HTAP_emis.m >& log_matlab


